import { useState } from "react";
import { useDispatch } from "react-redux";
import Swal from 'sweetalert2';
import { addTodo } from "../features/todo/todoSlice";

export default function AddForm() {
  const [task, setTask] = useState("");
  const dispatch = useDispatch();

  const submitHandler = (event) => {
    event.preventDefault();
    console.log(task);
    dispatch(addTodo(task));
    setTask("");

    // Display SweetAlert notification
    Swal.fire({
      title: 'Task Added!',
      text: 'You have successfully added a new task.',
      icon: 'success',
      confirmButtonText: 'OK'
    });
  };

  return (
    <>
      <form onSubmit={submitHandler}>
        <input type="text" className="bg-secondary p-2 m-2" value={task} onChange={(e) => setTask(e.target.value)} />
        <button type="submit">Add Task</button>
      </form>
    </>
  );
}
