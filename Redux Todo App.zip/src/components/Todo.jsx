import { useDispatch, useSelector } from "react-redux";
import Swal from "sweetalert2";
import AddForm from "./AddForm";
import { deleteTodo, markAsDone } from "../features/todo/todoSlice";
import { useState } from "react";

export default function Todo() {
  const todos = useSelector((state) => state.todos);
  const dispatch = useDispatch();
  const [state, setState] = useState("");

  const handleDelete = (id) => {
    dispatch(deleteTodo(id));
    Swal.fire({
      title: "Task Deleted!",
      text: "You have successfully deleted the task.",
      icon: "success",
      confirmButtonText: "OK",
    });
  };

  const handleDone = (id) => {
    dispatch(markAsDone(id));
    setState();
    Swal.fire({
      title: "Task Done!",
      text: "You have successfully marked the task as done.",
      icon: "success",
      confirmButtonText: "OK",
    });
  };

  return (
    <>
      <h3>Todo List App</h3>

      <AddForm />
      <div className="table-responsive">
        <table className="table table-bordered">
          <thead>
            <tr>
              <th scope="col">Task</th>
              <th scope="col">Actions</th>
            </tr>
          </thead>
          <tbody>
            {todos.map((todo) => (
              <tr key={todo.id}>
                <td className={todo.isDone ? "font-weight-bold text-success" : ""}>{todo.task}</td>
                <td>
                  <button
                    className="btn btn-danger mr-3"
                    onClick={() => handleDelete(todo.id)}
                  >
                    Delete Task
                  </button>
                  <button
                    className="btn btn-success"
                    onClick={() => handleDone(todo.id)}
                  >
                    Task Done
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
