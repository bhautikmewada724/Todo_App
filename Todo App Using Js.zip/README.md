# Todo App
A Todo list app built in vanilla javascript. It includes features like drag and drop tasks, filter tasks, edit and change tasks.

[Live Todo App](https://ankitsaxena21.github.io/Todo-App/)

![screenshot](https://github.com/ankitsaxena21/Todo-App/blob/master/Screenshot_2020-05-06%20Todo%20App.png)

It's easy to use. Clone the repository and play with it by opening it on your browser.
